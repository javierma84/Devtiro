package com.deviro.maven.services;

public interface BluePrinter {
  String print();
}
