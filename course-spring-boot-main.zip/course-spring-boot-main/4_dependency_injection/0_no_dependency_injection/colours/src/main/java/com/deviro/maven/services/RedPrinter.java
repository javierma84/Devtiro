package com.deviro.maven.services;

public interface RedPrinter {
  String print();
}
