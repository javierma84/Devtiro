package com.deviro.maven.services;

public interface GreenPrinter {
  String print();
}
