package com.deviro.maven.services;

public interface ColourPrinter {
  String print();
}
