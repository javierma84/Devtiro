package com.deviro.maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColoursApplicationIT {

  @Test
  void contextLoads() {}
}
