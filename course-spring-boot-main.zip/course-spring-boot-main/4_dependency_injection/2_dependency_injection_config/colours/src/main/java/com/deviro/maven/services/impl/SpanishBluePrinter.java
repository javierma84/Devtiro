package com.deviro.maven.services.impl;

import com.deviro.maven.services.BluePrinter;

public class SpanishBluePrinter implements BluePrinter {

  @Override
  public String print() {
    return "azul";
  }
}
